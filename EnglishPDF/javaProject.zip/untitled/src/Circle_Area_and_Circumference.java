public class Circle_Area_and_Circumference {
    public static void main(String[] args) {
        double radius = 3;

        double area = 3.14 * radius * radius;
        double circumference = 2 * 3.14 * radius;

        System.out.println( "The area of the circle is: " + area );
        System.out.println( "The circumference of the circle is: " + circumference );
    }
}
