public class CountVowelsAndConsonants {
    public static void main(String[] args) {
        String str = "This is a test string.";

        // Declare two variables to store the count of vowels and consonants.
        int vowelCount = 0;
        int consonantCount = 0;

        // Iterate over the string and check each character.
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            // If the character is a vowel, increment the vowel count.
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowelCount++;
            }

            // If the character is a consonant, increment the consonant count.
            else if (ch >= 'a' && ch <= 'z') {
                consonantCount++;
            }
        }

        // Print the count of vowels and consonants.
        System.out.println("Vowels: " + vowelCount);
        System.out.println("Consonants: " + consonantCount);
    }
}
