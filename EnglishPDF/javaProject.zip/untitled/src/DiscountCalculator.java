import java.util.Scanner;

public class DiscountCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the amount: ");
        double amount = sc.nextDouble();

        double discountPercentage = 0;
        if (amount > 20000) {
            discountPercentage = 15;
        } else if (amount > 10000) {
            discountPercentage = 10;
        } else if (amount > 5000) {
            discountPercentage = 7;
        } else {
            discountPercentage = 4;
        }

        double discountAmount = amount * discountPercentage / 100;
        double finalAmount = amount - discountAmount;

        System.out.println("The final amount is: " + finalAmount);
    }
}