import java.util.Scanner;
public class Calculator2 {
    public static void main(String[] args) {
        int num1, num2, operation, sum, diff, pro;
        float div;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter first number: ");
        num1 = sc.nextInt();

        System.out.println("Enter second number: ");
        num2 = sc.nextInt();

        System.out.println("Enter 1 for Addition");
        System.out.println("Enter 2 for Subtraction");
        System.out.println("Enter 3 for Multiplication");
        System.out.println("Enter 4 for Divison");
        System.out.println("Enter 5 for Exit");

        operation = sc.nextInt();

        switch (operation){
            case 1:
                sum = num1 + num2;
                System.out.println(sum);
                break;
            case 2:
                diff = num1 - num2;
                System.out.println(diff);
                break;
            case 3:
                pro = num1 * num2;
                System.out.println(pro);
                break;
            case 4:
                div = num1 / num2;
                System.out.println(div);
                break;
            case 5:
                System.exit(0);
                break;
        }
    }
}
