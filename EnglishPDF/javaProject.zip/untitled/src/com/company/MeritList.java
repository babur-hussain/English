package com.company;

import java.util.Scanner;

public class MeritList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of students: ");
        int ns = sc.nextInt();

        int [] roll = new int[ns];
        String [] name = new String[ns];
        float [] total = new float[ns];
        float [] percentage = new float[ns];
        float temp;
        int x;
        String n;

        for (int i = 0; i < ns; i++){
            System.out.println("Enter the roll no of the student " + (i + 1) + " " );
            roll[i] = sc.nextInt();

            System.out.println("Enter the name of the student " + (i + 1) + " " );
            name[i] = sc.next();

            System.out.println("Enter total marks of the student " + (i + 1) + " ");
            total[i] = sc.nextFloat();
        }
        for (int i = 0; i < ns; i++){
            percentage[i] = ( total[i] * 100 ) / 500;
        }
        for (int i = 0; i < ns; i++){
            for (int j = i+1; j < ns; j++ ){
                if (percentage[i] < percentage[j]) {
                    temp = percentage[i];
                    percentage[i] = percentage[j];
                    percentage[j] = temp;

                    x = roll[i];
                    roll[i] = roll[j];
                    roll[j] = x;

                    n = name[i];
                    name[i] = name[j];
                    name[j] = n;

                    temp = total[i];
                    total[i] = total[j];
                    total[j] = temp;

                }
            }
        }
        //print the merit list
        System.out.println("Roll Number\t | \t Name\t | \t Percentage");
        for (int i =0; i < ns; i++){
            System.out.println(roll[i] + "\t\t\t\t" + name[i] + "\t\t\t\t" + percentage[i] );
        }


        // Prepare and print the merit list
        System.out.println("Merit List");
        System.out.println("Roll No. | Name | Total Marks | Percentage");
        for (int i = 0; i < ns; i++) {
            for (int j = 0; j < ns; j++) {
                if (percentage[i] == percentage[j]) {
                    System.out.println(roll[j] + "      | " + name[j] + "      | " + total[j] + "      | " + percentage[j]);
                }
            }
        }

    }
}
