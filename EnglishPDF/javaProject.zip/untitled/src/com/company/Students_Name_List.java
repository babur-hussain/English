package com.company;

import java.util.Scanner;
public class Students_Name_List {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

       /* System.out.println("Enter the number of students: ");
        int ns = sc.nextInt(); */

        int[] roll = {1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
        float[] totalMarks = {375, 380, 440, 489, 433, 275, 250, 222, 287, 390, 450, 470, 233, 349, 444, 500, 390, 300, 290, 299};

       // String[] name = new String[ns];
      //  float[] total = new float[ns];
        float percentage;

       /* for (int i = 0; i < ns; i++) {
            System.out.println("Enter the name of the Student: ");
            name[i] = sc.next();

            System.out.println("Enter total Marks: ");
            total[i] = sc.nextInt();
        } */

        System.out.println("\tStudents with more than 60% ");
       /* for (int i = 0; i < 19; i++){

            if (percentage >= 60){
                System.out.println( "\t\t" + roll[i] + " - " + percentage + "%");
            }
        } */

        System.out.println("\tStudents with less than 60%");
        for (int i = 0; i < 19; i++){
            percentage = ( totalMarks[i] / 500 ) * 100;

            if (percentage < 60){
                System.out.println("\t\t" + roll[i] + " - " + percentage + "%");
            }
        }

    }
}