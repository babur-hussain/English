import java.util.Scanner;

public class MultiplicationTable {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number: ");
        int x = sc.nextInt();

        for (int y = 1; y <= 10; y++ ){
            int z = x * y;
            System.out.println( x + " * " +  y  + " = " + z );
        }
    }
}
