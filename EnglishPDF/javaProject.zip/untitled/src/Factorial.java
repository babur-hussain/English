public class Factorial {
    public static void main(String[] args) {
        int x, y = 1;
        int z = 5; // It is the number to calculate the factorial

        for (x = 1; x <= z; x++ ){
            y = y * x;
        }
        System.out.println("Factorial of " + z + " is: " + y);
    }
}
