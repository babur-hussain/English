import java.util.Scanner;
public class MarksArray {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of students: ");
        int ns = sc.nextInt();

        // Initialize arrays to store roll numbers and marks
        int[] rn = new int[ns];
        int[] marks = new int[ns];

        // Input roll numbers and marks for each student
        for (int i = 0; i < ns; i++) {
            System.out.print("Enter the roll number for student " + (i + 1) + ": ");
            rn[i] = sc.nextInt();

            System.out.print("Enter the marks for student " + (i + 1) + ": ");
            marks[i] = sc.nextInt();
        }

        // Display roll numbers and marks
        System.out.println("\nRoll Numbers and Marks:");
        for (int i = 0; i < ns; i++) {
            System.out.println("Student " + (i + 1) + " - Roll Number: " + rn[i] + ", Marks: " + marks[i]);
        }



        // Find the student with the highest marks
        int highestMarks = marks[0];
        int x = 0;
        for (int i = 1; i < ns; i++) {
            if (marks[i] > highestMarks) {
                highestMarks = marks[i];
                x = i;
            }
        }

        // Print the student with the highest marks
        System.out.println("\nStudent with the highest marks:");
        System.out.println("Roll Number: " + rn[x] + ", Marks: " + highestMarks);

        // Close the scanner
        sc.close();
    }
}
