import java.util.Scanner;
public class ReportCard_Array {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of students: ");
        int ns = sc.nextInt();

        /* Predefined roll numbers and marks for 5 students
        String[] rollNumbers = {"Student1", "Student2", "Student3", "Student4", "Student5"};
        double[] marksSubject1 = {90.5, 85.0, 78.5, 92.0, 88.5};
        double[] marksSubject2 = {88.0, 76.5, 92.5, 84.0, 90.0};
        double[] marksSubject3 = {76.0, 89.0, 80.5, 91.5, 87.0};
        double[] marksSubject4 = {85.5, 90.0, 88.0, 87.5, 84.5};
        double[] marksSubject5 = {92.5, 78.5, 85.0, 89.0, 91.0};

         */

                // Initialize arrays to store roll numbers and marks for 5 subjects
                int[] rn = new int[ns];
                float[] Phy = new float[ns];
                float[] Chem = new float[ns];
                float[] Maths = new float[ns];
                float[] It = new float[ns];
                float[] Eng = new float[ns];

                // Input data for ns number of students
                for (int i = 0; i < ns; i++) {
                    System.out.print("Enter Roll Number for Student " + (i + 1) + ": ");
                    rn[i] = sc.nextInt();

                    System.out.print("Enter Marks for Physics for Student " + (i + 1) + ": ");
                    Phy[i] = sc.nextFloat();

                    System.out.print("Enter Marks for Chemistry for Student " + (i + 1) + ": ");
                    Chem[i] = sc.nextFloat();

                    System.out.print("Enter Marks for Maths for Student " + (i + 1) + ": ");
                    Maths[i] = sc.nextFloat();

                    System.out.print("Enter Marks for It for Student " + (i + 1) + ": ");
                    It[i] = sc.nextFloat();

                    System.out.print("Enter Marks for English for Student " + (i + 1) + ": ");
                    Eng[i] = sc.nextFloat();
                }

                // Calculate total marks and percentage for each student
                String[] remarks = new String[ns];
                String[] result = new String[ns];

                float[] totalMarks = new float[ns];
                float[] percentages = new float[ns];
                for (int i = 0; i < ns; i++) {
                    totalMarks[i] = Phy[i] + Chem[i] + Maths[i] + It[i] + Eng[i];
                    percentages[i] = (totalMarks[i] / 500) * 100;
                }

                // Print the information in tabular form
                System.out.println("------------------------------------------------------------");
                System.out.println("Roll Number | Physics | Chemistry | Maths | It | English | Total Marks | Percentage");
                System.out.println("------------------------------------------------------------");

                /* for (int i = 0; i < ns; i++) {
                    System.out.printf("%-12s | %-10.2f | %-10.2f | %-10.2f | %-10.2f | %-10.2f | %-11.2f | %-10.2f%%%n",
                            rn[i], Phy[i], Chem[i], Maths[i], It[i], Eng[i], totalMarks[i], percentages[i]);
                }*/

        for (int i = 0; i < ns; i++) {
            System.out.print(rn[i] + "\t\t | ");
            System.out.print(Phy[i] + "\t\t | ");
            System.out.print(Chem[i] + "\t\t | ");
            System.out.print(Maths[i] + "\t\t | ");
            System.out.print(It[i] + "\t\t | ");
            System.out.print(Eng[i] + "\t\t | ");
            System.out.print(totalMarks[i] + "\t\t | ");
            System.out.println(percentages[i] + "\t\t %");
        }

        System.out.println("------------------------------------------------------------");

        for (int i = 0; i < ns; i++){
            if (percentages[i] >= 33){
                result[i] = "Pass";
            }
            else {
                result[i] = "Failed";
            }
            System.out.println("Result: " + result[i] );
        }

        for (int i = 0; i < ns; i++) {
            if (percentages[i] >= 80.0) {
                remarks[i] = "Excellent";
            } else if (percentages[i] >= 60.0) {
                remarks[i] = "Good";
            } else if (percentages[i] >= 40.0) {
                remarks[i] = "Average";
            } else {
                remarks[i] = "Needs Improvement";
            }
            System.out.println("remark: " + remarks[i] );
        }
                sc.close();
    }
}
