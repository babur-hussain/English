import java.util.Scanner;

public class Percentage {
    public static void main(String[] args) {
        float Phy, Chem, Maths, It, Eng;

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Physics Marks: ");
        Phy = sc.nextFloat();
        System.out.println("Enter Chemistry Marks: ");
        Chem = sc.nextFloat();
        System.out.println("Enter Maths Marks: ");
        Maths = sc.nextFloat();
        System.out.println("Enter It Marks: ");
        It = sc.nextFloat();
        System.out.println("Enter English Marks: ");
        Eng = sc.nextFloat();

        float Percentage = (Phy + Chem + Maths + It + Eng) * 100 / 500;

        System.out.println("The Percentage is: " + Percentage);
    }
}
