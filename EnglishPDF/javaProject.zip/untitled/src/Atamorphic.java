public class Atamorphic {
    public static void main(String[] args) {
        int x = 9, d, s;
        while (x < 99){
            x++;
            d = x % 10;
            s = x % 100;

            if ( d == s){
                System.out.println(" Automorphic ");
            }
            else {
                System.out.println("Not an Automorphic");
            }

        }
    }
}
