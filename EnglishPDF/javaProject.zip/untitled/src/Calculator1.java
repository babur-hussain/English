import java.util.Scanner;
public class Calculator1 {
    public static void main(String[] args) {
        float x, y, z = 0;
        char a;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number: ");
        x = sc.nextInt();

        System.out.println("Enter second number: ");
        y = sc.nextInt();

        System.out.println("Choose action to perform ( +  -  *  / ) ");
        a = sc.next().charAt(0);

        if (a == '+'){
            z = x + y;
        }
        else if (a == '-'){
            z = x - y;
        }
        else if (a == '*'){
            z = x * y;
        }
        else if (a == '/'){
            z = x / y;
        }
        else {
            System.out.println("Invalid Input");
        }
        System.out.println(x + " " + a + " " + y + " = " + z);

    }
}
