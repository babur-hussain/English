import java.util.Scanner;
public class ArrayMarks {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of students: ");
        int ns = sc.nextInt();

        int[] rn = new int[ns];
        int [] marks = new int[ns];
        for (int i = 0; i < ns; i++ ){
            System.out.println("Enter roll no of student " + (i + 1 ) + ": " );
            rn[i] = sc.nextInt();
            System.out.println("Enter marks of student " + (i + 1) + ": " );
            marks[i] = sc.nextInt();
        }

        System.out.println("Roll no and Marks");
        for ( int i = 0; i < ns; i++ ){
            System.out.println("Student " + (i + 1) + " - Roll Number: " + rn[i] + ", Marks: " + marks[i] );
        }

        int HighestMarks = marks[0];
        int x = 1;
        for ( int i = 1; i < ns; i++ ){
            if ( marks[i] > HighestMarks ){
                HighestMarks = marks[i];
                x = i;
            }
        }

        System.out.println("Student with the highest Marks: ");
        System.out.println("Roll no: " + rn[x] + ", Marks: " + HighestMarks);

    }
}