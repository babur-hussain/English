import java.util.Scanner;

public class StudentMarks {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the marks for the first subject: ");
        int subject1Marks = sc.nextInt();

        System.out.print("Enter the marks for the second subject: ");
        int subject2Marks = sc.nextInt();

        System.out.print("Enter the marks for the third subject: ");
        int subject3Marks = sc.nextInt();

        System.out.print("Enter the marks for the fourth subject: ");
        int subject4Marks = sc.nextInt();

        System.out.print("Enter the marks for the fifth subject: ");
        int subject5Marks = sc.nextInt();

        int totalMarks = subject1Marks + subject2Marks + subject3Marks + subject4Marks + subject5Marks;
        double averageMarks = totalMarks / 5.0;

        String remark;
        if (averageMarks >= 90) {
            remark = "Excellent";
        } else if (averageMarks >= 80 && averageMarks < 90) {
            remark = "Very Good";
        } else if (averageMarks >= 65 && averageMarks < 80) {
            remark = "Good";
        } else if (averageMarks >= 40 && averageMarks < 65) {
            remark = "Work Hard";
        } else {
            remark = "Fail";
        }

        System.out.println("Total marks: " + totalMarks);
        System.out.println("Average marks: " + averageMarks);
        System.out.println("Remark: " + remark);
    }
}
